import cclib
import sys

def extract_ts_structure(gaussian_output_file):
    """
    Extracts the final optimized geometry from a Gaussian output file.
    """
    try:
        # Parse the log file
        data = cclib.io.ccread(gaussian_output_file)

        # Check if the calculation converged successfully
        if data.optdone:
            # The last set of coordinates in the optimization history
            final_coords = data.atomcoords[-1]
            atoms = data.atomnos

            # Format into XYZ format
            xyz_output = f"{len(atoms)}\n"
            xyz_output += "Transition State Optimized Structure\n"
            for i, atom_num in enumerate(atoms):
                symbol = cclib.core.elements.element_symbol[atom_num]
                x, y, z = final_coords[i]
                xyz_output += f"{symbol} {x:10.6f} {y:10.6f} {z:10.6f}\n"

            return xyz_output
        else:
            return "Error: Optimization did not converge successfully."

    except Exception as e:
        return f"Error parsing file: {e}"

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python extract_ts_script.py <gaussian_output_file.log>")
        sys.exit(1)

    output_file = sys.argv[1]
    ts_structure_xyz = extract_ts_structure(output_file)

    if ts_structure_xyz.startswith("Error"):
        print(ts_structure_xyz)
    else:
        with open(f"{output_file}_ts.xyz", "w") as f:
            f.write(ts_structure_xyz)
        print(f"Transition state structure saved to {output_file}_ts.xyz")


