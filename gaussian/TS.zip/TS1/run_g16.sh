#!/bin/bash -l
##
## Job Name as it will appear on squeue
#SBATCH --job-name="Gaussian 2016"
##
## Number of cores. Try to pick a multiple of 40 when using the general partition.
#SBATCH --tasks=40
##
## The partition to use
#SBATCH --partition=bigmem

##Note: G16 will not run on multiple nodes. Requests should be 40 cores or less.

# Load Modules and Program Settings
module load gaussian/g16
setenv GAUSS_SCRDIR `pwd`
source $G16PATH/bsd/g16.login
source $G16PATH/bsd/g16.profile

# Run the program


system=$1


#cd $SLURM_SUBMIT_DIR/$system


if [ ! -d "g16_scratch" ]; then
  mkdir g16_scratch
fi
export GAUSS_SCRDIR=g16_scratch

echo $system

G16JOB=${system}.gjf
JOBname=`basename $G16JOB .gjf`

sed -i "s/Distance_Value/${2}/g" ${G16JOB}

g16 < $G16JOB > $JOBname.log
formchk $JOBname.chk $JOBname.fchk
rm -rf g16_scratch

# Delete any core dumps or Gau files
rm -rf Gau-*
rm -rf core*
rm -rf *.rwf

